$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
Working with Character Matrices
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

.. toctree::
    :maxdepth: 2

    chars.rst
    popgenstats.rst
