$$$$$$$$$$$$$$$$$
Working with Taxa
$$$$$$$$$$$$$$$$$

.. toctree::
    :maxdepth: 2

    taxa.rst
    taxa_partitions.rst
