*********************************************************************
:mod:`dendropy.treecalc` -- Tree Statistics, Metrics and Calculations
*********************************************************************

.. module:: treecalc

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.treecalc
    :members:
