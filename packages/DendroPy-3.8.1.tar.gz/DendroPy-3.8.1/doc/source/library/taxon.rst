**********************************************
:mod:`dendropy.dataobject.taxon` -- Taxon Data
**********************************************

.. module:: dendropy.dataobject.taxa

.. toctree::
    :maxdepth: 2

The :class:`TaxonSet` Class
=============================
.. autoclass:: dendropy.dataobject.taxon.TaxonSet
    :members:

The :class:`Taxon` Class
========================
.. autoclass:: dendropy.dataobject.taxon.Taxon
    :members:
