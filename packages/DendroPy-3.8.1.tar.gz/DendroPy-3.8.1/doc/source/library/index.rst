##########################
DendroPy Library Reference
##########################

.. toctree::
    :maxdepth: 2

    dataset.rst
    taxon.rst
    tree.rst
    char.rst
    coalescent.rst
    reconcile.rst
    treecalc.rst
    treemanip.rst
    treesim.rst
    ncbi.rst
