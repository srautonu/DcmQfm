********************************************************************
:mod:`dendropy.coalescent` -- Coalescent Calculations and Statistics
********************************************************************

.. module:: coalescent

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.coalescent
    :members:
