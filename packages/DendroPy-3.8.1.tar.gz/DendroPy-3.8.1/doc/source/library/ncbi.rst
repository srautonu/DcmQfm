******************************************************
:mod:`dendropy.interop.ncbi` -- NCBI Database Querying
******************************************************

.. module:: dendropy.interop.ncbi

.. toctree::
    :maxdepth: 2

The :class:`Entrez` Class
===========================
.. autoclass:: dendropy.interop.ncbi.Entrez
    :members:
